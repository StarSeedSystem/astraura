"""
starseed_bridge.py — Puente oficial Astraura 1.58-bit ⇄ StarSeed OS (Adenda 153 del OS).

Tres rutas pequeñas y estables que el OS usa para tratar a este backend como su
SISTEMA PRIMARIO de inteligencia (ver en el repo del OS
`architecture/astraura-158-sistema-primario.md`):

  GET  /api/starseed/health    — latido ligero (sin telemetría pesada).
  GET  /api/starseed/manifest  — motor + personalidades + agentes + habilidades +
                                 cerebros en UNA llamada (el panel del OS).
  POST /api/starseed/chat      — chat con `messages[]` estilo OpenAI (system/user/
                                 assistant). El backend es single-turn: aquí se
                                 construye la transcripción en el servidor y se
                                 reusa `orchestrator.generate_response_stream`,
                                 devolviendo el MISMO SSE que /api/chat/stream
                                 (branching_plan · agent_traces · token · done).

Compatibilidad: si un OS antiguo no conoce estas rutas sigue usando
/api/chat/stream; si un backend antiguo no las tiene, el OS recibe 404 y cae a
/api/chat/stream. Sin dependencias nuevas.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter(prefix="/api/starseed", tags=["StarSeed OS bridge"])

BRIDGE_VERSION = "1.0.0"
HISTORY_BUDGET_CHARS = 9000


class BridgeMessage(BaseModel):
    role: str
    content: str


class BridgeChatRequest(BaseModel):
    messages: List[BridgeMessage]
    persona_id: Optional[str] = None
    system_prompt: Optional[str] = None
    preferences: Optional[Dict[str, Any]] = None
    stream: Optional[bool] = True


def build_prompt(messages: List[BridgeMessage], extra_system: Optional[str] = None) -> Dict[str, str]:
    """Transcripción single-turn (misma regla que el adaptador del OS)."""
    systems = [m.content.strip() for m in messages if m.role == "system" and m.content.strip()]
    if extra_system and extra_system.strip():
        systems.append(extra_system.strip())
    system_prompt = "\n\n".join(systems)
    turns = [m for m in messages if m.role != "system"]
    if not turns:
        return {"system_prompt": system_prompt, "prompt": ""}
    last = turns[-1]
    last_user = last.content if last.role == "user" else ""
    history = turns[:-1] if last.role == "user" else turns
    if not history:
        return {"system_prompt": system_prompt, "prompt": last_user.strip()}
    lines: List[str] = []
    used = 0
    for m in reversed(history):
        who = "Usuario" if m.role == "user" else "Astraura"
        line = f"{who}: {m.content.strip()}"
        if used + len(line) > HISTORY_BUDGET_CHARS:
            break
        lines.insert(0, line)
        used += len(line) + 1
    transcript = "\n".join(lines)
    if last_user:
        prompt = (
            "Transcripción de la conversación hasta ahora (responde SOLO al último mensaje "
            "del usuario, sin repetir la transcripción):\n"
            f"{transcript}\n\nÚltimo mensaje del usuario:\n{last_user.strip()}"
        )
    else:
        prompt = f"Transcripción de la conversación hasta ahora. Continúa de forma natural:\n{transcript}"
    return {"system_prompt": system_prompt, "prompt": prompt}


def _safe(fn, default):
    try:
        return fn()
    except Exception:
        return default


@router.get("/health")
async def starseed_health():
    from ..engine.bitnet_engine import bitnet_engine
    engine = _safe(bitnet_engine.get_engine_status, {})
    return {
        "status": "online",
        "bridge": BRIDGE_VERSION,
        "engine": {
            "active_model": engine.get("active_model"),
            "bitnet_cpp_installed": engine.get("bitnet_cpp_installed"),
            "models_on_disk": len(engine.get("models_on_disk") or []),
        },
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


@router.get("/manifest")
async def starseed_manifest():
    from ..engine.bitnet_engine import bitnet_engine
    from ..personalities.personality_engine import personality_engine
    from ..skills.starseed_library import starseed_library
    from ..core.agent_vault_engine import agent_vault_engine
    from ..agents.agent_registry import agent_registry
    from ..cerebros.cerebros_manager import cerebros_manager

    engine = _safe(bitnet_engine.get_engine_status, {})
    personalities = _safe(personality_engine.list_personalities, [])
    active = _safe(personality_engine.get_active_persona, {}) or {}
    skills = _safe(starseed_library.get_all_skills, [])
    vault_agents = [dict(a, origin="vault") for a in (_safe(agent_vault_engine.list_agents, []) or [])]
    eco_agents = [dict(a, origin="ecosystem") for a in (_safe(agent_registry.get_all_agents, []) or [])]
    cerebros = _safe(cerebros_manager.get_cerebros, {}) or {}

    # Catálogo compacto: el OS no necesita los prompts completos ni las claves.
    def slim_persona(p: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "id": p.get("id"),
            "name": p.get("name"),
            "title": p.get("title"),
            "color": p.get("color"),
            "description": (p.get("description") or "")[:240],
            "is_custom": bool(p.get("is_custom")),
            "temperature": p.get("temperature"),
            "voice_profile": {
                "voice_id": (p.get("voice_profile") or {}).get("voice_id"),
                "caracter": (p.get("voice_profile") or {}).get("caracter"),
            },
            "tags": p.get("tags") or [],
        }

    def slim_brain(b: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "id": b.get("id"),
            "name": b.get("name"),
            "scope": b.get("scope"),
            "role": b.get("role"),
            "color": b.get("color"),
            "active_persona": b.get("active_persona"),
            "md_layers": {k: (v or "")[:160] for k, v in (b.get("md_layers") or {}).items()},
            "memory_neurons": [
                {"id": n.get("id"), "name": n.get("name"), "type": n.get("type"), "enabled": n.get("enabled", True)}
                for n in (b.get("memory_neurons") or [])
            ],
            "linked_personalities": b.get("linked_personalities") or [],
        }

    return {
        "bridge": BRIDGE_VERSION,
        "status": {"status": "online", "engine": engine},
        "personalities": [slim_persona(p) for p in personalities],
        "active_persona_id": active.get("id"),
        "agents": vault_agents + eco_agents,
        "skills": skills,
        "cerebros": [slim_brain(b) for b in (cerebros.get("cerebros") or [])],
        "active_brain_id": cerebros.get("active_brain_id"),
    }


@router.post("/chat")
async def starseed_chat(req: BridgeChatRequest):
    from ..agents.orchestrator import orchestrator

    built = build_prompt(req.messages, req.system_prompt)
    prefs: Dict[str, Any] = dict(req.preferences or {})
    if req.persona_id:
        prefs.setdefault("personaId", req.persona_id)
        prefs.setdefault("selected_personalities", [req.persona_id])
    prefs.setdefault("multi_personality_mode", "single")
    prefs.setdefault("client", "starseed-os")

    if not built["prompt"].strip():
        return {"error": "messages sin mensaje de usuario"}

    if req.stream is False:
        full = ""
        async for event in orchestrator.generate_response_stream(built["prompt"], built["system_prompt"], preferences=prefs):
            if event.get("type") == "token":
                full += event.get("token", "")
            elif event.get("type") == "done" and not full:
                full = event.get("full_text", "")
        return {"response": full, "persona_id": req.persona_id, "bridge": BRIDGE_VERSION}

    async def sse_generator():
        async for event in orchestrator.generate_response_stream(built["prompt"], built["system_prompt"], preferences=prefs):
            yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

    return StreamingResponse(sse_generator(), media_type="text/event-stream")
